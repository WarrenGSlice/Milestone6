package com.example.contactsapp1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class EditContact extends AppCompatActivity {
    Button btn_Save, btn_exit, btn_delete;
    List<People> peopleList;
    EditText et_personName, et_PersonDate, et_PersonImageUrl, et_personStreet, et_personCity, et_personZip, et_personState, et_personCountry, et_personEmail, et_personPhone;
    TextView tv_idNumber;
    int id;

    MyApplication myApplication = (MyApplication) this.getApplication();

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_contact);

        peopleList = myApplication.getPeopleList();

        btn_delete = findViewById(R.id.btn_delete);
        btn_Save = findViewById(R.id.btn_Save);
        btn_exit = findViewById(R.id.btn_exit);
        et_personName = findViewById(R.id.et_personName);
        et_PersonDate = findViewById(R.id.et_PersonDate);
        et_PersonImageUrl = findViewById(R.id.et_PersonImageUrl);
        et_personStreet = findViewById(R.id.et_personStreet);
        et_personCity = findViewById(R.id.et_personCity);
        et_personZip = findViewById(R.id.et_personZip);
        et_personState = findViewById(R.id.et_personState);
        et_personCountry = findViewById(R.id.et_personCountry);
        et_personEmail = findViewById(R.id.et_personEmail);
        tv_idNumber = findViewById(R.id.tv_idNumber);
        et_personPhone = findViewById(R.id.et_PersonPhone);

        Intent intent = getIntent();

        id = intent.getIntExtra("id", -1);
        People people = null;

        if (id >=0) {
            //edit the contact
            for (People p: peopleList) {
                if (p.getId() == id ) {
                    people = p;
                }
            }
            et_personName.setText(people.getName());
            et_PersonImageUrl.setText(people.getImageURL());
            et_PersonDate.setText(String.valueOf(people.getDateOfBirth()));
            tv_idNumber.setText(String.valueOf(id));
            et_personCity.setText(people.getCity());
            et_personCountry.setText(people.getCountry());
            et_personEmail.setText(people.getEmail());
            et_personStreet.setText(people.getStreet());
            et_personState.setText(people.getState());
            et_personZip.setText(String.valueOf(et_personZip));
            et_personPhone.setText(people.getPhone());
        }
        else {
            // create new person
        }

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (id >=0) {

                    //Update
                    People updatedPeople = new People(id,et_personName.getText().toString(), Integer.parseInt(et_PersonDate.getText().toString()), et_PersonImageUrl.getText().toString(), et_personStreet.getText().toString(), et_personCity.getText().toString(), et_personState.getText().toString(), et_personZip.getText().toString(), et_personCountry.getText().toString(), et_personEmail.getText().toString(), et_personPhone.getText().toString());
                    peopleList.set(id, updatedPeople);
                }
                else{
                    // add new person
                    //Create Person object
                    int nextId = MyApplication.getNextId();
                    People newPeople = new People(nextId,et_personName.getText().toString(), Integer.parseInt(et_PersonDate.getText().toString()), et_PersonImageUrl.getText().toString(), et_personStreet.getText().toString(), et_personCity.getText().toString(), et_personState.getText().toString(), et_personZip.getText().toString(), et_personCountry.getText().toString(), et_personEmail.getText().toString(), et_personPhone.getText().toString());

                    //add the object of the global list of people
                    peopleList.add(newPeople);
                    MyApplication.setNextId(nextId++);
                }

                //go back to main activity
                Intent intent = new Intent(EditContact.this, ContactList.class);
                startActivity(intent);
            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditContact.this, ContactList.class);
                startActivity(intent);
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remove the contact from the list
                id = intent.getIntExtra("id", -1);
                People people = null;
                if (id >=0) {
                    //edit the contact
                    for (People p: peopleList) {
                        if (p.getId() == id ) {
                            people = p;
                        }
                    }
                    peopleList.remove(people);
                    Intent intent = new Intent(EditContact.this, ContactList.class);
                    startActivity(intent);
                }
            }
        });
    }
}
