package com.example.contactsapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    Button btn_addContact, btn_showContacts, btn_exit, btn_SearchByProp, btn_SearchByID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_addContact = findViewById(R.id.btn_addContact);
        btn_showContacts = findViewById(R.id.btn_showContacts);
        btn_exit = findViewById(R.id.btn_exit);
        btn_SearchByProp = findViewById(R.id.btn_SearchByProp);
        btn_SearchByID = findViewById(R.id.btn_SearchByID);

        btn_addContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, Add_a_Contact.class );
                startActivity(intent);
            }
        });

        btn_showContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, ContactList.class);
                startActivity(intent);
            }
        });
    }

}