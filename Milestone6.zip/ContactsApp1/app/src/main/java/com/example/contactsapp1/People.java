package com.example.contactsapp1;

import java.util.Comparator;

public class People {
    private int id;
    private String name;
    private int dateOfBirth;
    private String imageURL;
    private String street;
    private String city;
    private String state;
    private String zip;
    private String country;
    private String email;
    private String phone;

    public People(int id, String name, int dateOfBirth, String imageURL, String street, String city, String state, String zip, String country, String email, String phone) {
        this.id = id;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.imageURL = imageURL;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.country = country;
        this.email = email;
        this.phone = phone;
    }

    public static Comparator<People> PeopleNameAZComparator = new Comparator<People>() {
        @Override
        public int compare(People p1, People p2) {
            return p1.getName().compareTo(p2.getName());
        }
    };

    public static Comparator<People> PeopleNameZAComparator = new Comparator<People>() {
        @Override
        public int compare(People p1, People p2) {
            return p2.getName().compareTo(p1.getName());
        }
    };

    public static Comparator<People> PeopleDateAscendingComparator = new Comparator<People>() {
        @Override
        public int compare(People p1, People p2) {
            return p1.getDateOfBirth() - p2.getDateOfBirth();
        }
    };

    public static Comparator<People> PeopleDateDescendingComparator = new Comparator<People>() {
        @Override
        public int compare(People p1, People p2) {
            return p2.getDateOfBirth() - p1.getDateOfBirth();
        }
    };

    public static Comparator<People> PeopleIdAscendingComparator = new Comparator<People>() {
        @Override
        public int compare(People p1, People p2) {
            return p1.getId() - p2.getId();
        }
    };

    public static Comparator<People> PeopleIdDescendingComparator = new Comparator<People>() {
        @Override
        public int compare(People p1, People p2) {
            return p2.getId() - p1.getId();
        }
    };

    @Override
    public String toString() {
        return "People{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", imageURL='" + imageURL + '\'' +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zip=" + zip +
                ", country='" + country + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(int dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
