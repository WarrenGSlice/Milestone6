package com.example.contactsapp1;

import android.app.Application;

import com.example.contactsapp1.People;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyApplication extends Application {

    private static List<People> peopleList = new ArrayList<People>();
    private static int nextId = 10;

    public MyApplication() {
        fillPeopleList();
    }


    private void fillPeopleList() {
        People p0 = new People(0, "Jessica Harris", 1991, "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MXx8cGVyc29ufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "14220 NW Haverstine Blvd", " Maple Valley", "WA", "98038", "USA", "JessicaHarris@Gmail.com", "360-251-5654");
        People p1 = new People(1, "Nessa Jorgensen", 1987, "https://images.unsplash.com/photo-1542103749-8ef59b94f47e?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Mnx8cGVyc29ufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "350 NE 4th St.", "Puyallup", "WA", "97070", "USA", "Nessa@Gmail.com", "503-981-1234");
        People p2 = new People(2, "Sergio de Paulo", 1986, "https://images.unsplash.com/flagged/photo-1570612861542-284f4c12e75f?ixid=MXwxMjA3fDB8MHxzZWFyY2h8M3x8cGVyc29ufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "2828 Larch St.", "Longview", "WA", "98632", "USA", "Sergio@Gmail.com", "253-985-4565");
        People p3 = new People(3, "Jamie Freckles", 1995, "https://images.unsplash.com/photo-1554151228-14d9def656e4?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Nnx8cGVyc29ufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "1928 Hoyt St.", "Portland", "OR", "97210", "USA", "FreckleFace@Gmail.com", "456-4561-7894");
        People p4 = new People(4, "Jonas Kakarato", 1982,"https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?ixid=MXwxMjA3fDB8MHxzZWFyY2h8NXx8cGVyc29ufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "9710 Pennsylvania Ave", "Washington", "DC", "10001", "USA", "JonasPatriot@Gmail.com", "808-725-6524" );
        People p5 = new People(5, "Olivia Ferrero", 1990, "https://images.unsplash.com/photo-1491349174775-aaafddd81942?ixid=MXwxMjA3fDB8MHxzZWFyY2h8OHx8cGVyc29ufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "1001 Green Bay Ave", "Green Bay", "WI", "60021", "USA", "PackerFan@Gmail.com", "202-321-3233");
        People p6 = new People(6,"Ryan Fitzpatrick", 1985, "https://images.unsplash.com/photo-1552058544-f2b08422138a?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTB8fHBlcnNvbnxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "4567 Dream Ave", "Cloud City", "CO", "87510", "USA", "StarWarsFan@Gmail.com", "606-656-6626");
        People p7 = new People(7, "Ethan Hoover", 1998, "https://images.unsplash.com/photo-1500048993953-d23a436266cf?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTJ8fHBlcnNvbnxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "78211 Harlem Blvd.", "Harlem", "NY", "20010", "USA", "Globetrotter@Gmail.com", "911-211-2233");
        People p8 = new People(8, "Kelly Silkemma", 2000, "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTN8fHBlcnNvbnxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "5656 Slow Grind St.", "Decaf", "TX", "42001", "USA", "CoffeeFreak@Gmail.com", "755-427-2727");
        People p9 = new People(9, "Bonnie Tyler", 1997, "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTd8fHBlcnNvbnxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "4455 Kenny St.", "Boise", "ID", "92541", "USA", "Techie@Gmail.com", "206-321-3011");

        peopleList.addAll(Arrays.asList(new People[] { p0, p1, p2, p3, p4, p5, p6, p7, p8, p9}));

    }

    public static List<People> getPeopleList() {
        return peopleList;
    }

    public static void setPeopleList(List<People> peopleList) {
        MyApplication.peopleList = peopleList;
    }

    public static int getNextId() {
        return nextId;
    }

    public static void setNextId(int nextId) {
        MyApplication.nextId = nextId;
    }
}
